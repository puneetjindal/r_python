## Author: Ingo Feinerer

## Preprocess the Reuters-21578 XML data available at
## http://modnlp.berlios.de/reuters21578.html
preprocess_Reuters_21578_XML <-
function(input, output, fixEnc = TRUE)
{
    dir.create(output, recursive = TRUE)
    files <- dir(input, pattern = "\\.xml", full.names = TRUE)

    if (fixEnc) {
        ## Correct invalid UTF-8 encoding
        ## The invalid multibyte string is in reut2-017.xml at line 35578
        reut2_017 <- file.path(input, "reut2-017.xml")
        if (file.exists(reut2_017)) {
            content <- readLines(reut2_017)
            content[35578] <- "world economic growth. side measures to boost growth, he said."
            writeLines(content, reut2_017)
        } else
            warning("could not find ", reut2_017)
    }

    ## Write out each article in a separate file
    counter <- 1
    for (f in files) {
        tree <- XML::xmlParse(f)
        XML::xmlApply(XML::xmlRoot(tree),
            function(article) {
                output.file <-
                    file.path(output, sprintf("reut-%s.xml",
                        formatC(counter, width = 5, format ="d", flag = "0")))
                counter <<- counter + 1
                con <- file(output.file, "w")
                XML::saveXML(article, file = con)
                close(con)
            })
        XML::free(tree)
    }
}
