# Author: Ingo Feinerer

# The Modified Lewis ("ModLewis") Split:
#
# Training Set (13,625 docs): LEWISSPLIT="TRAIN";  TOPICS="YES" or "NO"
# Test Set (6,188 docs):  LEWISSPLIT="TEST"; TOPICS="YES" or "NO"
# Unused (1,765): LEWISSPLIT="NOT-USED" or TOPICS="BYPASS"
ModLewisSplit <-
function(doc)
{
    LEWISSPLIT <- meta(doc, "lewissplit")
    TOPICS <- meta(doc, "topics")

    (identical(LEWISSPLIT, "TRAIN") && (identical(TOPICS, "YES") || identical(TOPICS, "NO"))) ||
    (identical(LEWISSPLIT, "TEST") && (identical(TOPICS, "YES") || identical(TOPICS, "NO")))
}

# The Modified Apte ("ModApte") Split :
#
# Training Set (9,603 docs): LEWISSPLIT="TRAIN";  TOPICS="YES"
# Test Set (3,299 docs): LEWISSPLIT="TEST"; TOPICS="YES"
# Unused (8,676 docs): LEWISSPLIT="NOT-USED"; TOPICS="YES" or TOPICS="NO" or TOPICS="BYPASS"
ModApteSplit <-
function(doc)
{
    LEWISSPLIT <- meta(doc, "lewissplit")
    TOPICS <- meta(doc, "topics")

    (identical(LEWISSPLIT, "TRAIN") && identical(TOPICS, "YES")) ||
    (identical(LEWISSPLIT, "TEST") && identical(TOPICS, "YES"))
}

# The Modified Hayes ("ModHayes") Split:
#
# Training Set (20856 docs): CGISPLIT="TRAINING-SET"
# Test Set (722 docs): CGISPLIT="PUBLISHED-TESTSET"
# Unused (0 docs)
ModHayesSplit <-
function(doc)
{
    CGISPLIT <- meta(doc, "cgisplit")

    identical(CGISPLIT, "TRAINING-SET") || identical(CGISPLIT, "PUBLISHED-TESTSET")
}
